var firebaseConfig = {
    apiKey: "AIzaSyAzMRcTTq-GxC15LNcxiqlztwh1TxuDahU",
    authDomain: "blog-19d15.firebaseapp.com",
    databaseURL: "https://blog-19d15.firebaseio.com",
    projectId: "blog-19d15",
    storageBucket: "blog-19d15.appspot.com",
    messagingSenderId: "998709368265",
    appId: "1:998709368265:web:b01544921ce210a0"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);